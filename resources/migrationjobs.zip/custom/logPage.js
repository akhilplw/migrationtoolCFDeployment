sap.ui.define(["sap/m/MessageBox"],function(e){"use strict";return{buttonPressed:function(e){}}});
//# sourceMappingURL=logPage.js.map